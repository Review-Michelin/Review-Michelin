package com.example.rechelin

data class StoreEntity(var store:String, var score:String) //또는 Int
